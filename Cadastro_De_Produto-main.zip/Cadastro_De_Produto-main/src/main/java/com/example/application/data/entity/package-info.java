@NonNullApi
package com.example.application.data.entity;

import org.springframework.lang.NonNullApi;